import mysql.connector

def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="123456789",
        database="studentsdb"  
    )

def display_records(cursor):
    print("\nAll Student Records:")
    cursor.execute("SELECT * FROM StudentScores")
    for row in cursor.fetchall():
        print(row)

def show_average_marks(cursor):
    print("\nAverage Marks per Student:")
    cursor.execute("""
        SELECT name, AVG(marks) AS average_marks
        FROM StudentScores
        GROUP BY name
    """)
    for row in cursor.fetchall():
        print(f"{row[0]} - {row[1]:.2f}")

def students_below_40(cursor):
    print("\nStudents scoring < 40 in any subject:")
    cursor.execute("SELECT name, subject, marks FROM StudentScores WHERE marks < 40")
    for row in cursor.fetchall():
        print(row)


# Main Program
conn = connect_db()
cursor = conn.cursor()

display_records(cursor)
show_average_marks(cursor)
students_below_40(cursor)

# Cleanup
cursor.close()
conn.close()