CREATE TABLE StudentScores (
    name VARCHAR(100),
    subject VARCHAR(100),
    marks INT
);

INSERT INTO StudentScores (name, subject, marks) VALUES
('Aarthi', 'Math', 85),
('Bhavana', 'Science', 32),
('Charulatha', 'Math', 58),
('Aarthi', 'Science', 90),
('Bhavana', 'Math', 40),
('Dhivya', 'English', 25),
('Charulatha', 'Science', 70),
('Aarthi', 'English', 38),
('Dhivya', 'Math', 95);




