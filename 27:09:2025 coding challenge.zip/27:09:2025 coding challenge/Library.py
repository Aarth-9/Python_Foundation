class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author
        self.is_borrowed = False

    def __str__(self):
        status = "Borrowed" if self.is_borrowed else "Available"
        return f"'{self.title}' by {self.author} [{status}]"

class Library:
    def __init__(self, name):
        self.name = name
        self.books = []

    def add_book(self, book):
        self.books.append(book)

    def view_books(self):
        print(f"\nBooks in {self.name}:")
        for book in self.books:
            print(book)

    def borrow_book(self, title):
        for book in self.books:
            if book.title.lower() == title.lower() and not book.is_borrowed:
                book.is_borrowed = True
                return book
        return None
    
    def return_book(self, title):
        for book in self.books:
            if book.title.lower() == title.lower() and book.is_borrowed:
                book.is_borrowed = False
                return True
        return False

class User(Library):
    def __init__(self, name, library):
        self.user_name = name
        self.library = library
        self.borrowed_books = []

    def view_books(self):
        print(f"\n{self.user_name}'s View of Library:")
        self.library.view_books()

    def borrow_book(self, title):
        book = self.library.borrow_book(title)
        if book:
            self.borrowed_books.append(book)
            print(f"\n{self.user_name} borrowed '{book.title}'")
        else:
            print(f"\n'{title}' is not available for borrowing.")

    def return_book(self, title):
        success = self.library.return_book(title)
        if success:
            self.borrowed_books = [b for b in self.borrowed_books if b.title.lower() != title.lower()]
            print(f"\n{self.user_name} returned '{title}'")
        else:
            print(f"\nBook not found or not borrowed.")

lib = Library("City Library")
lib.add_book(Book("Python Basics", "Bhavna"))
lib.add_book(Book("Data Structures", "Aarthi"))
lib.add_book(Book("OOP in Python", "Akshaya"))


user1 = User("Getsy", lib)


user1.view_books()
user1.borrow_book("Python Basics")
user1.borrow_book("OOP in Python")
user1.view_books()

user1.return_book("Python Basics")
user1.view_books()
