import unittest
from unittest.mock import patch
from Movie_Booking_System import Movie_Booking_System 

class TestMovieBookingSystem(unittest.TestCase):

    def setUp(self):
        self.booking_system = Movie_Booking_System()

    def tearDown(self):
        del self.booking_system

    def test_calculate_amount(self):
        amount = self.booking_system.calculate_amount("Arya2", 3)
        self.assertEqual(amount, 600)

    @patch('builtins.input', side_effect=["3", "2"]) 
    def test_book_movie(self, mock_input):
        self.booking_system.book_movie()


if __name__ == '__main__':
    unittest.main()