def Postfix_Expression():
    expr = "231*+9-"
    stack = []

    for i in expr:
        if i.isdigit():
            stack.append(int(i))
        else:
            b = stack.pop()
            a = stack.pop()
            if i == "+":
                stack.append(a+b)
            elif i == "-":
                stack.append(a-b)
            elif i == "*" :
                stack.append(a*b)
            elif i == '/':
                stack.append(a//b)
    
    return stack.pop()

print(Postfix_Expression())

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = new_node

    def display(self):
        temp = self.head
        print("Linked List:", end=" ")
        while temp:
            print(temp.data, end=" -> ")
            temp = temp.next
        print("None")

    def reverse(self):
        prev = None
        curr = self.head
        while curr:
            next_node = curr.next
            curr.next = prev
            prev = curr
            curr = next_node
        self.head = prev

l = LinkedList()
l.append(5)
l.append(10)
l.append(15)
l.append(20)
l.display()
l.reverse()
l.display()