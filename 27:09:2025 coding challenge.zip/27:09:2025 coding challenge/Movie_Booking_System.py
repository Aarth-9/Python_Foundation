class Movie_Booking_System:
    def __init__(self):
        self.movies = {
            "Arya2" : 200,
            "Deva" : 300,
            "Vikram" : 250,
            "Joker" : 500
        }

    def available_movies(self):
        print("\nAvailable Movies:")
        for index, (movie, price) in enumerate(self.movies.items(), start=1):
            print(f"{index}. {movie} - ₹{price} per ticket")

    def calculate_amount(self, movie, tickets):
        return self.movies[movie] * tickets
    
    def book_movie(self):
        self.available_movies()
        try:
            choice = int(input("\nEnter the number corresponding to the movie: "))
            if 1 <= choice <= len(self.movies):
                movie = list(self.movies.keys())[choice - 1]
                tickets = int(input(f"How many tickets for '{movie}'? "))
                total = self.calculate_amount(movie, tickets)
                print(f"\n Booking Confirmed for '{movie}'")
                print(f"Tickets: {tickets} | Total Amount: ₹{total}")
            else:
                print("Invalid movie selection.")
        except ValueError:
            print("Invalid input. Please enter numeric values.")


s = Movie_Booking_System()
s.book_movie()